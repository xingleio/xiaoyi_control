from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers.v1.api import api_router

app = FastAPI(title="小怡课表API", version="1.0.0")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 测试根路由
@app.get("/")
def read_root():
    return {"Hello": "World"}

# 注册v1版本的路由
app.include_router(api_router, prefix="/api/v1")
